# fhir.education.kursig#0.1.0: Test av dagen

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Min fina profil](StructureDefinition-EducationEncounter.md)
* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [Test av dagen](index.md)

### Examples

* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
